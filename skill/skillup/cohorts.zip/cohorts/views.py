from django.shortcuts import render

# Create your views here.
from django.http.response import HttpResponseRedirect
from django.shortcuts import render, redirect
from django.views.generic import View
from django.http import JsonResponse
# from   .models import User,Profile, Faculty
# from user
# from .ots_email import send_otp
from django.contrib.auth import authenticate,login
# from .models import generate_otp
from django.contrib.auth.mixins import LoginRequiredMixin,UserPassesTestMixin
import pdb
from django.urls import reverse
from user.models import Profile,Faculty,User 
from django.core.paginator import Paginator
from django.core.mail import EmailMessage
from django.conf import settings
from django.core.paginator  import Paginator,EmptyPage,PageNotAnInteger
from django.core.mail import EmailMultiAlternatives
from django.template.loader import render_to_string
from user .passcodegen import generate_passcode
from .models import CohortGroup




class ListAdminCohort(LoginRequiredMixin,UserPassesTestMixin,View):
    login_url = login
    def test_func(self):
        return self.request.user.is_staff 
    def handle_no_permission(self):
         return redirect('login')
    
    def get(self,request):
                pdb.set_trace
                cohort_list = CohortGroup.objects.count()
                context = {
                       'cohort_list':cohort_list
                }
                return render(request, 'admin/cohortlist.html', context=context)
    
    def get(self,request):
                return render(request, 'admin/cohortlist.html')
        