from django.urls import path




urlpatterns = [
   
    path('',Dash.as_view(), name='dash'),
  
   



    
    

]